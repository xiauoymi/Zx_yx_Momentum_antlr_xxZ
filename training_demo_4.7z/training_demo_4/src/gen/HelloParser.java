// Generated from C:\Dell\ALL\WorkSpace\momentum\training_demo_4\HelloParser.g4 by ANTLR 4.5.1
package gen;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class HelloParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.5.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		SALUTE=1, MALE=2, FEMALE=3, HELLO=4, ID=5, IS=6, WS=7, CIGAR=8, WSML=9, 
		PERFUME=10, IDD=11, WSWN=12;
	public static final int
		RULE_statements = 0, RULE_r = 1, RULE_id = 2, RULE_newline = 3, RULE_gender = 4, 
		RULE_male = 5, RULE_female = 6;
	public static final String[] ruleNames = {
		"statements", "r", "id", "newline", "gender", "male", "female"
	};

	private static final String[] _LITERAL_NAMES = {
		null, null, "'male'", "'female'", "'hello'", null, null, null, "'cigar'", 
		null, "'perfume'"
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, "SALUTE", "MALE", "FEMALE", "HELLO", "ID", "IS", "WS", "CIGAR", 
		"WSML", "PERFUME", "IDD", "WSWN"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "HelloParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public HelloParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class StatementsContext extends ParserRuleContext {
		public List<RContext> r() {
			return getRuleContexts(RContext.class);
		}
		public RContext r(int i) {
			return getRuleContext(RContext.class,i);
		}
		public NewlineContext newline() {
			return getRuleContext(NewlineContext.class,0);
		}
		public StatementsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statements; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HelloParserListener ) ((HelloParserListener)listener).enterStatements(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HelloParserListener ) ((HelloParserListener)listener).exitStatements(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HelloParserVisitor ) return ((HelloParserVisitor<? extends T>)visitor).visitStatements(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StatementsContext statements() throws RecognitionException {
		StatementsContext _localctx = new StatementsContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_statements);
		int _la;
		try {
			setState(20);
			switch (_input.LA(1)) {
			case HELLO:
				enterOuterAlt(_localctx, 1);
				{
				setState(15); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(14);
					r();
					}
					}
					setState(17); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==HELLO );
				}
				break;
			case EOF:
				enterOuterAlt(_localctx, 2);
				{
				setState(19);
				newline();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RContext extends ParserRuleContext {
		public Token SALUTE;
		public TerminalNode HELLO() { return getToken(HelloParser.HELLO, 0); }
		public TerminalNode SALUTE() { return getToken(HelloParser.SALUTE, 0); }
		public GenderContext gender() {
			return getRuleContext(GenderContext.class,0);
		}
		public List<IdContext> id() {
			return getRuleContexts(IdContext.class);
		}
		public IdContext id(int i) {
			return getRuleContext(IdContext.class,i);
		}
		public TerminalNode IS() { return getToken(HelloParser.IS, 0); }
		public TerminalNode IDD() { return getToken(HelloParser.IDD, 0); }
		public TerminalNode CIGAR() { return getToken(HelloParser.CIGAR, 0); }
		public TerminalNode PERFUME() { return getToken(HelloParser.PERFUME, 0); }
		public RContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_r; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HelloParserListener ) ((HelloParserListener)listener).enterR(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HelloParserListener ) ((HelloParserListener)listener).exitR(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HelloParserVisitor ) return ((HelloParserVisitor<? extends T>)visitor).visitR(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RContext r() throws RecognitionException {
		RContext _localctx = new RContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_r);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(22);
			match(HELLO);
			setState(23);
			((RContext)_localctx).SALUTE = match(SALUTE);
			setState(25); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(24);
					id();
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(27); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,2,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(30);
			switch ( getInterpreter().adaptivePredict(_input,3,_ctx) ) {
			case 1:
				{
				setState(29);
				match(IS);
				}
				break;
			}
			setState(32);
			gender((((RContext)_localctx).SALUTE!=null?((RContext)_localctx).SALUTE.getText():null));
			setState(34);
			_la = _input.LA(1);
			if (_la==IDD) {
				{
				setState(33);
				match(IDD);
				}
			}

			setState(37);
			_la = _input.LA(1);
			if (_la==CIGAR || _la==PERFUME) {
				{
				setState(36);
				_la = _input.LA(1);
				if ( !(_la==CIGAR || _la==PERFUME) ) {
				_errHandler.recoverInline(this);
				} else {
					consume();
				}
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IdContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(HelloParser.ID, 0); }
		public IdContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_id; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HelloParserListener ) ((HelloParserListener)listener).enterId(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HelloParserListener ) ((HelloParserListener)listener).exitId(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HelloParserVisitor ) return ((HelloParserVisitor<? extends T>)visitor).visitId(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IdContext id() throws RecognitionException {
		IdContext _localctx = new IdContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_id);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(39);
			match(ID);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NewlineContext extends ParserRuleContext {
		public NewlineContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_newline; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HelloParserListener ) ((HelloParserListener)listener).enterNewline(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HelloParserListener ) ((HelloParserListener)listener).exitNewline(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HelloParserVisitor ) return ((HelloParserVisitor<? extends T>)visitor).visitNewline(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NewlineContext newline() throws RecognitionException {
		NewlineContext _localctx = new NewlineContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_newline);
		try {
			enterOuterAlt(_localctx, 1);
			{
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class GenderContext extends ParserRuleContext {
		public String salute;
		public MaleContext male() {
			return getRuleContext(MaleContext.class,0);
		}
		public FemaleContext female() {
			return getRuleContext(FemaleContext.class,0);
		}
		public GenderContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public GenderContext(ParserRuleContext parent, int invokingState, String salute) {
			super(parent, invokingState);
			this.salute = salute;
		}
		@Override public int getRuleIndex() { return RULE_gender; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HelloParserListener ) ((HelloParserListener)listener).enterGender(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HelloParserListener ) ((HelloParserListener)listener).exitGender(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HelloParserVisitor ) return ((HelloParserVisitor<? extends T>)visitor).visitGender(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GenderContext gender(String salute) throws RecognitionException {
		GenderContext _localctx = new GenderContext(_ctx, getState(), salute);
		enterRule(_localctx, 8, RULE_gender);
		try {
			setState(47);
			switch ( getInterpreter().adaptivePredict(_input,6,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(43);
				if (!(_localctx.salute.equals("mr"))) throw new FailedPredicateException(this, "$salute.equals(\"mr\")");
				setState(44);
				male();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(45);
				if (!(!_localctx.salute.equals("mr"))) throw new FailedPredicateException(this, "!$salute.equals(\"mr\")");
				setState(46);
				female();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MaleContext extends ParserRuleContext {
		public TerminalNode MALE() { return getToken(HelloParser.MALE, 0); }
		public MaleContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_male; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HelloParserListener ) ((HelloParserListener)listener).enterMale(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HelloParserListener ) ((HelloParserListener)listener).exitMale(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HelloParserVisitor ) return ((HelloParserVisitor<? extends T>)visitor).visitMale(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MaleContext male() throws RecognitionException {
		MaleContext _localctx = new MaleContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_male);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(49);
			match(MALE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FemaleContext extends ParserRuleContext {
		public TerminalNode FEMALE() { return getToken(HelloParser.FEMALE, 0); }
		public FemaleContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_female; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HelloParserListener ) ((HelloParserListener)listener).enterFemale(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HelloParserListener ) ((HelloParserListener)listener).exitFemale(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HelloParserVisitor ) return ((HelloParserVisitor<? extends T>)visitor).visitFemale(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FemaleContext female() throws RecognitionException {
		FemaleContext _localctx = new FemaleContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_female);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(51);
			match(FEMALE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 4:
			return gender_sempred((GenderContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean gender_sempred(GenderContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return _localctx.salute.equals("mr");
		case 1:
			return !_localctx.salute.equals("mr");
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3\168\4\2\t\2\4\3\t"+
		"\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\3\2\6\2\22\n\2\r\2\16\2\23"+
		"\3\2\5\2\27\n\2\3\3\3\3\3\3\6\3\34\n\3\r\3\16\3\35\3\3\5\3!\n\3\3\3\3"+
		"\3\5\3%\n\3\3\3\5\3(\n\3\3\4\3\4\3\5\3\5\3\6\3\6\3\6\3\6\5\6\62\n\6\3"+
		"\7\3\7\3\b\3\b\3\b\2\2\t\2\4\6\b\n\f\16\2\3\4\2\n\n\f\f\67\2\26\3\2\2"+
		"\2\4\30\3\2\2\2\6)\3\2\2\2\b+\3\2\2\2\n\61\3\2\2\2\f\63\3\2\2\2\16\65"+
		"\3\2\2\2\20\22\5\4\3\2\21\20\3\2\2\2\22\23\3\2\2\2\23\21\3\2\2\2\23\24"+
		"\3\2\2\2\24\27\3\2\2\2\25\27\5\b\5\2\26\21\3\2\2\2\26\25\3\2\2\2\27\3"+
		"\3\2\2\2\30\31\7\6\2\2\31\33\7\3\2\2\32\34\5\6\4\2\33\32\3\2\2\2\34\35"+
		"\3\2\2\2\35\33\3\2\2\2\35\36\3\2\2\2\36 \3\2\2\2\37!\7\b\2\2 \37\3\2\2"+
		"\2 !\3\2\2\2!\"\3\2\2\2\"$\5\n\6\2#%\7\r\2\2$#\3\2\2\2$%\3\2\2\2%\'\3"+
		"\2\2\2&(\t\2\2\2\'&\3\2\2\2\'(\3\2\2\2(\5\3\2\2\2)*\7\7\2\2*\7\3\2\2\2"+
		"+,\3\2\2\2,\t\3\2\2\2-.\6\6\2\3.\62\5\f\7\2/\60\6\6\3\3\60\62\5\16\b\2"+
		"\61-\3\2\2\2\61/\3\2\2\2\62\13\3\2\2\2\63\64\7\4\2\2\64\r\3\2\2\2\65\66"+
		"\7\5\2\2\66\17\3\2\2\2\t\23\26\35 $\'\61";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}
// Generated from C:\Dell\ALL\WorkSpace\momentum\training_demo_4\HelloParser.g4 by ANTLR 4.5.1
package gen;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link HelloParser}.
 */
public interface HelloParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link HelloParser#statements}.
	 * @param ctx the parse tree
	 */
	void enterStatements(HelloParser.StatementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link HelloParser#statements}.
	 * @param ctx the parse tree
	 */
	void exitStatements(HelloParser.StatementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link HelloParser#r}.
	 * @param ctx the parse tree
	 */
	void enterR(HelloParser.RContext ctx);
	/**
	 * Exit a parse tree produced by {@link HelloParser#r}.
	 * @param ctx the parse tree
	 */
	void exitR(HelloParser.RContext ctx);
	/**
	 * Enter a parse tree produced by {@link HelloParser#id}.
	 * @param ctx the parse tree
	 */
	void enterId(HelloParser.IdContext ctx);
	/**
	 * Exit a parse tree produced by {@link HelloParser#id}.
	 * @param ctx the parse tree
	 */
	void exitId(HelloParser.IdContext ctx);
	/**
	 * Enter a parse tree produced by {@link HelloParser#newline}.
	 * @param ctx the parse tree
	 */
	void enterNewline(HelloParser.NewlineContext ctx);
	/**
	 * Exit a parse tree produced by {@link HelloParser#newline}.
	 * @param ctx the parse tree
	 */
	void exitNewline(HelloParser.NewlineContext ctx);
	/**
	 * Enter a parse tree produced by {@link HelloParser#gender}.
	 * @param ctx the parse tree
	 */
	void enterGender(HelloParser.GenderContext ctx);
	/**
	 * Exit a parse tree produced by {@link HelloParser#gender}.
	 * @param ctx the parse tree
	 */
	void exitGender(HelloParser.GenderContext ctx);
	/**
	 * Enter a parse tree produced by {@link HelloParser#male}.
	 * @param ctx the parse tree
	 */
	void enterMale(HelloParser.MaleContext ctx);
	/**
	 * Exit a parse tree produced by {@link HelloParser#male}.
	 * @param ctx the parse tree
	 */
	void exitMale(HelloParser.MaleContext ctx);
	/**
	 * Enter a parse tree produced by {@link HelloParser#female}.
	 * @param ctx the parse tree
	 */
	void enterFemale(HelloParser.FemaleContext ctx);
	/**
	 * Exit a parse tree produced by {@link HelloParser#female}.
	 * @param ctx the parse tree
	 */
	void exitFemale(HelloParser.FemaleContext ctx);
}
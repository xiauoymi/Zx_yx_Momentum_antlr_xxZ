// Generated from C:\Dell\ALL\WorkSpace\momentum\training_demo_4\HelloParser.g4 by ANTLR 4.5.1
package gen;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link HelloParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface HelloParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link HelloParser#statements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStatements(HelloParser.StatementsContext ctx);
	/**
	 * Visit a parse tree produced by {@link HelloParser#r}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitR(HelloParser.RContext ctx);
	/**
	 * Visit a parse tree produced by {@link HelloParser#id}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitId(HelloParser.IdContext ctx);
	/**
	 * Visit a parse tree produced by {@link HelloParser#newline}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNewline(HelloParser.NewlineContext ctx);
	/**
	 * Visit a parse tree produced by {@link HelloParser#gender}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGender(HelloParser.GenderContext ctx);
	/**
	 * Visit a parse tree produced by {@link HelloParser#male}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMale(HelloParser.MaleContext ctx);
	/**
	 * Visit a parse tree produced by {@link HelloParser#female}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFemale(HelloParser.FemaleContext ctx);
}
package main;

import gen.HelloParser.IdContext;
import gen.HelloParser.RContext;
import gen.HelloParser.StatementsContext;
import gen.HelloParserBaseListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.stringtemplate.v4.ST;
import org.stringtemplate.v4.STGroupFile;

public class HelloListener extends HelloParserBaseListener{
	STGroupFile group = new STGroupFile("hello.stg");

	int maleCounter;
	int femaleCounter;
	
	@Override
	public void enterR(RContext ctx) {
		// TODO Auto-generated method stub
		super.enterR(ctx);
	
		DataCollectorBean d = ctx.accept(new HelloVisitor());
		System.out.println(d);
		
		ST st = group.getInstanceOf("htmlGreeting");
		if (st != null) {
			st.add("salute", ctx.SALUTE.getText());
			st.add("name", ctx.
					id(0).getText());
			
			System.out.println(st.render());
		}

		Map<String,String> values= new HashMap<String,String>();
		values.put("salute", ctx.SALUTE.getText() );
		values.put("name", ctx.id(0).getText());
		ST st1 = group.getInstanceOf("htmlGreetingMap");
		if (st1 != null) {
			st1.add("mapvalues", values);
			System.out.println(st1.render());
		}
		
	
		ST st2 = group.getInstanceOf("htmlGreetingMapAnony");
		if (st2 != null) {
			st2.add("mapvalues", values);
			System.out.println(st2.render());
		}
		
		List<String> valueList = new ArrayList<String>();
		valueList.add(ctx.SALUTE.getText());
		for(IdContext id : ctx.id()){
			valueList.add(id.getText());
		}
		ST st3 = group.getInstanceOf("htmlGreetingList");
		if (st3 != null) {
			st3.add("listvalues", valueList);
			System.out.println(st3.render());
		}
	
		ST st4 = group.getInstanceOf("htmlGreetingFlag");
		if (st4 != null) {
			st4.add("mapvalues", values);
			st4.add("listvalues", valueList);
			st4.add("flag", "");
			System.out.println(st4.render());
		}
			if(ctx.gender().male()!=null) maleCounter++;
			if(ctx.gender().female()!=null) femaleCounter++;
		
	
		System.out.println("Total Males in the training room is "+ maleCounter);
		System.out.println("Total Females in the training room is "+ femaleCounter);
		
	}


	@Override
	public void enterStatements(StatementsContext ctx) {
		// TODO Auto-generated method stub
		super.enterStatements(ctx);
		
		
		
		
		
		
	}
	
	


}

	
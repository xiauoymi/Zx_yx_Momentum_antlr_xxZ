package main;

import gen.HelloLexer;
import gen.HelloParser;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

public class TestStream {
	static  ANTLRInputStream input;
	public static void main(String[] args) throws Exception {
		
		//File fn = new File("E:\\momentum\\training_demo_3\\datadef.txt");
		//FileInputStream fileIo= new FileInputStream(fn);
		
		//C:\Dell\ALL\WorkSpace\momentum\training_demo_4\datadef.txt
		 Path path = Paths.get("C:/Dell/ALL/WorkSpace/momentum/training_demo_4/datadef.txt", "datadef.txt");
//		    The stream hence file will also be closed here
		    try(Stream<String> lines = Files.lines(path)){
		
		    
		lines.forEach(l -> {walktheSourceLine(l);});
		// create a CharStream that reads from standard input
		
		    }
		
	}

	
	private static void walktheSourceLine(String line){
		ANTLRInputStream input = new ANTLRInputStream(line);
		// create a lexer that feeds off of input CharStream
		HelloLexer lexer = new HelloLexer(input);
		// create a buffer of tokens pulled from the lexer
		CommonTokenStream tokens = new CommonTokenStream(lexer);
		
		// create a parser that feeds off the tokens buffer
		HelloParser parser = new HelloParser(tokens);

		ParseTree tree = parser.statements(); // begin parsing at init rule
		//System.out.println(tree.toStringTree(parser)); // print LISP-style tree
		ParseTreeWalker walker = new ParseTreeWalker(); // create standard walker
		HelloListener extractor = new HelloListener();
		walker.walk(extractor, tree); // initiate walk of tree with listener
		System.out.println("end");

	}
	
	public HelloLexer getComment (HelloParser hp){
		return new HelloLexer(input);
	}
}
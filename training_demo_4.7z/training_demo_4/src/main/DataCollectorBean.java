package main;

public class DataCollectorBean {
	
	String salute;
	String name;
	public String getSalute() {
		return salute;
	}
	public void setSalute(String salute) {
		this.salute = salute;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "DataCollectorBean [salute=" + salute + ", name=" + name + "]";
	}
	
	
	

}

package main;

import gen.HelloParser.IdContext;
import gen.HelloParser.RContext;
import gen.HelloParser.StatementsContext;
import gen.HelloParserBaseVisitor;


/**
 * @author sbindumadhavan
 *
 */
/**
 * @author sbindumadhavan
 *
 */
/**
 * @author sbindumadhavan
 *
 */
/**
 * @author sbindumadhavan
 *
 */
/**
 * @author sbindumadhavan
 *
 */
public class HelloVisitor extends HelloParserBaseVisitor<DataCollectorBean> {

	/* (non-Javadoc)
	 * @see gen.HelloParserBaseVisitor#visitR(gen.HelloParser.RContext)
	 */
	/* (non-Javadoc)
	 * @see gen.HelloParserBaseVisitor#visitR(gen.HelloParser.RContext)
	 */
	/* (non-Javadoc)
	 * @see gen.HelloParserBaseVisitor#visitR(gen.HelloParser.RContext)
	 */
	@Override
	
	public DataCollectorBean visitR(RContext ctx) {
		// TODO Auto-generated method stub
	
		
		 super.visitR(ctx);
		 DataCollectorBean dcb = new DataCollectorBean();
		 dcb.setName(ctx.id(0).getText());
		 dcb.setSalute(ctx.SALUTE.getText());
		
		 return dcb;
	}


	/* (non-Javadoc)
	 * @see gen.HelloParserBaseVisitor#visitStatements(gen.HelloParser.StatementsContext)
	 */

	@Override
	public DataCollectorBean visitId(IdContext ctx) {
		// TODO Auto-generated method stub
		return super.visitId(ctx);
	}


	@Override
	public DataCollectorBean visitStatements(StatementsContext ctx) {
		// TODO Auto-generated method stub
		 super.visitStatements(ctx);
		 DataCollectorBean dcb = new DataCollectorBean();

	     return dcb;
	}

	

	/**
	 *  
	 * @param abc
	 * @param sbc
	 * @return
	 * 
	 */
	public DataCollectorBean testMethod(String abc, int sbc){
		return new DataCollectorBean();
	}
	
	
}

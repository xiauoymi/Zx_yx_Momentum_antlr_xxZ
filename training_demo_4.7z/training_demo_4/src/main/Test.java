package main;

import gen.HelloLexer;
import gen.HelloParser;
import gen.HelloParser.StatementsContext;

import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.Future;

import javax.swing.JDialog;

import org.antlr.v4.gui.Trees;
import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

public class Test {
	static  ANTLRInputStream input;
	public static void main(String[] args) throws Exception {
		
//		File fn = new File("E:\\momentum\\training_demo_4\\datadef.txt");
		File fn = new File("C:\\Dell\\ALL\\WorkSpace\\momentum\\training_demo_4\\datadef.txt");
		
		FileInputStream fileIo= new FileInputStream(fn);
		
		// create a CharStream that reads from standard input
		ANTLRInputStream input = new ANTLRInputStream(fileIo);
		// create a lexer that feeds off of input CharStream
		HelloLexer lexer = new HelloLexer(input);
		// create a buffer of tokens pulled from the lexer
		CommonTokenStream tokens = new CommonTokenStream(lexer);
		// create a parser that feeds off the tokens buffer
		HelloParser parser = new HelloParser(tokens);
		ParseTree tree = parser.statements(); 
		
		StatementsContext sc = parser.statements();
		Future<JDialog> viewer = Trees.inspect(sc, parser);
		
		Trees.save(sc, parser,"C:\\Dell\\ALL\\WorkSpace\\momentum\\training_demo_4\\datadef.ps" );
		
		while(!viewer.isDone()){
			System.out.println("building tree");
		}
		
//		JDialog viewwindow = viewer.get();
//		viewwindow.validate();
		
		// begin parsing at init rule
		System.out.println(tree.toStringTree(parser)); // print LISP-style tree
		ParseTreeWalker walker = new ParseTreeWalker(); // create standard walker
		HelloListener extractor = new HelloListener();
		walker.walk(extractor, tree); // initiate walk of tree with listener
		System.out.println("end");
		
		
		
	}
	
	
	public HelloLexer getComment (HelloParser hp){
		return new HelloLexer(input);
	}
}